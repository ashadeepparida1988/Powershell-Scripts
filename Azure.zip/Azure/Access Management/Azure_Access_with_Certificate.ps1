﻿##############################################
# Script for Obtaining authentication to Azure

# Self Signed Certificate --> New Service Principal with Cert Value and Dates --> Role Assignment Scope to your current subscription 

# Use Connect-AzAccount to login to azure before running this script.

#Requirements 
#Modules Az, PKI(In case there is no Windows 10 or Windows Server 2016) 

##############################################
#region Parameters

param(
    
    #path to variable files
    $pathToJson = ""
)

#endregion

#################
#region Functions

Function SelfSignedCertificate {
param(
     
)
try{

    # New Self Signed Certificate
    $notAfter = (Get-Date).AddMonths(6)  # Valid for 6 months
    $script:cert = New-SelfSignedCertificate -CertStoreLocation "cert:\$certStoreLocation" -Subject "CN=$subject" -KeySpec $keySpec -NotAfter $notAfter

    # Get certificate raw data
    $script:keyValue = [System.Convert]::ToBase64String($cert.GetRawCertData())

}
catch{
    
    $errorSSC = "Error while creating self signed certificate - $($error[0].Message)"
    $errorSSC
}    

}

Function New-ADServicePrincipal {
param(

)
try{
    
    #Create New Service Principal
    $script:servicePrincipal = New-AzADServicePrincipal -DisplayName $servicePrincipalName -CertValue $keyValue -EndDate $cert.NotAfter -StartDate $cert.NotBefore
    
}catch{

    $errorSP = "Error while creating service principal - $($error[0].Message)"
    $errorSP

}

}

Function RoleAssignment {
param(

)
try{
    
    # Assign role to service principal
    New-AzRoleAssignment -RoleDefinitionName $roleDefinition -ServicePrincipalName $servicePrincipal.ApplicationId

}catch{
    
    $errorRA = "Error while assigning role to service principal - $($error[0].Message)"
    $errorRA
}

}

Function ValidateServicePrincipal {
param(

)
try{
    
    #Get Tenant Id
    $tenantId = (Get-AzSubscription).TenantId

    #Get Service Principal
    $applicationID = (Get-AzADApplication -DisplayName $servicePrincipalName).ApplicationId
    
    #Get Cert Thumbprint
    $thumbprint = (Get-ChildItem "cert:$certStoreLocation" | Where-Object {$_.Subject -eq "CN=$subject" }).Thumbprint 

    #Disconnect existing Login
    Disconnect-AzAccount

    #Connect again using service principal
    $newLogin = Connect-AzAccount -ServicePrincipal -CertificateThumbprint $Thumbprint -ApplicationId $ApplicationId -TenantId $TenantId
    if($newLogin){
        
        "Login Successful using service principal"
    }
    else{
        
        "Login Failed using service principal.$($error[0])"
    }

}catch{
    
    $errorVa = "Error while assigning role to service principal - $($error[0].Message)"
    $errorVa
}

}

Function LoginToAzure{
param(
)
    
    #Check Login to Azure
    $checkLogin = Get-AzSubscription -ErrorAction silentlyContinue
    if($checkLogin){
        
        "We are already logged into azure with subscription: $($checkLogin.Name)"
    }
    else{
        
        #Login to Azure using credentials of the user having sufficient access to create service principal
        "Please login to azure with user having sufficient privileges to create service principal..."
        $checkConnect = Connect-AzAccount 
        if($checkConnect){
            
            "Successfully Logged in to Azure."
        }
        else{
            
            "Unable to Login to Azure"
            Exit
        }
    }
     

}
#endregion


#################
#region Variables

#Get Inputs from JSON
#$getVars = get-content -path $pathToJson -Force

# Cert Store Location:- "CurrentUser\My Location"
$certStoreLocation = "C:\Temp\ScriptCertStore" # $getVars.certStoreLocation

# General name such as script name or team name
$subject = "EOPSAutomation"

# type of key such as KeyExchange, None or Signature
$keySpec = "KeyExchange"

# Name for new service principal
$servicePrincipalName = "EOPSAutomation"

# Role to be assigned to service principal such as Reader, Contributor or Owner
$roleDefinition = "Contributor"

# Subcsription ID in case non default subscription to be used
$subscriptionID = ""

# Set Subscription in case subscription id is provided
if($subscriptionID){
    
    # Set Different Subscription
    Set-AzContext -Subscription $subscriptionID
}

# Validate Cert Store Location
if((Test-Path -Path $certStoreLocation) -eq $false){
    
    "Path to Cert Location doesn't exist."
    "Trying to Create the same path."
    New-Item -Path $certStoreLocation -ItemType Directory -Force
    if((Test-Path -Path $certStoreLocation) -eq $false){
        
        "Unable to create the same path. Please provide the already existing path"
    }
    else{
        
        "Same path has been created."
    }
}
#endregion


#################
#region Main

LoginToAzure

SelfSignedCertificate

New-ADServicePrincipal

RoleAssignment

ValidateServicePrincipal
#endregion