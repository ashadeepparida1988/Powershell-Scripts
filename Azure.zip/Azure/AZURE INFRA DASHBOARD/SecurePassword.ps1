﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	PowerShell ISE
	 Created on:   	3 June 2020
	 Created by:   	Rahul Sawant
	 Organization: 	HCL Technologies
	 Email:         sawantrahul.sanjay@hcl.com
	 Filename:     	SecurePassword.ps1
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#----------------------------------------------
# Generated Form Function
#----------------------------------------------
function Show-Paasword_Form_psf
{
	
	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
	#endregion Import Assemblies
	
	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formSecurePassword = New-Object 'System.Windows.Forms.Form'
	$textbox2 = New-Object 'System.Windows.Forms.TextBox'
	$labelOutputFolder = New-Object 'System.Windows.Forms.Label'
	$textbox1 = New-Object 'System.Windows.Forms.TextBox'
	$labelEnterPassword = New-Object 'System.Windows.Forms.Label'
	$buttonCreate = New-Object 'System.Windows.Forms.Button'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects
	
	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	
	$formSecurePassword_Load = {
		#TODO: Initialize Form Controls here
		$textbox2.text = [Environment]::GetFolderPath("Desktop")
	}
	
	$buttonCreate_Click = {
		$Password = $textbox1.Text
		$Location = $textbox2.Text
		$Location = $Location.Replace('"', '')
		if ([string]::IsNullOrEmpty($Password))
		{
			[System.Windows.Forms.MessageBox]::Show("Please enter password ", 'Password field is empty')
			$confim = $false
		}
		if ([string]::IsNullOrEmpty($Location))
		{
			[System.Windows.Forms.MessageBox]::Show("Please enter output folder ", 'Folder field is empty')
			$confim = $false
		}
		if ((Test-Path $Location) -eq $false)
		{
			[System.Windows.Forms.MessageBox]::Show("output folder is not valid, please enter valid path ", 'Location not found')
			$confim = $false
		}
		
		if ($confirm -ne $false)
		{
			$outfile = $Location + '\Password.txt'
			$Password | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString | Out-File $outfile
		}
	}
	
	# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load =
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$formSecurePassword.WindowState = $InitialFormWindowState
	}
	
	$Form_Cleanup_FormClosed =
	{
		#Remove all event handlers from the controls
		try
		{
			$buttonCreate.remove_Click($buttonCreate_Click)
			$formSecurePassword.remove_Load($formSecurePassword_Load)
			$formSecurePassword.remove_Load($Form_StateCorrection_Load)
			$formSecurePassword.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch { Out-Null <# Prevent PSScriptAnalyzer warning #> }
	}
	#endregion Generated Events
	
	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	$formSecurePassword.SuspendLayout()
	#
	# formSecurePassword
	#
	$formSecurePassword.Controls.Add($textbox2)
	$formSecurePassword.Controls.Add($labelOutputFolder)
	$formSecurePassword.Controls.Add($textbox1)
	$formSecurePassword.Controls.Add($labelEnterPassword)
	$formSecurePassword.Controls.Add($buttonCreate)
	$formSecurePassword.AcceptButton = $buttonCreate
	$formSecurePassword.AutoScaleDimensions = '6, 13'
	$formSecurePassword.AutoScaleMode = 'Font'
	$formSecurePassword.ClientSize = '391, 150'
	$formSecurePassword.FormBorderStyle = 'FixedDialog'
	$formSecurePassword.MaximizeBox = $False
	$formSecurePassword.MinimizeBox = $False
	$formSecurePassword.Name = 'formSecurePassword'
	$formSecurePassword.StartPosition = 'CenterScreen'
	$formSecurePassword.Text = 'Secure Password'
	$formSecurePassword.add_Load($formSecurePassword_Load)
	#
	# textbox2
	#
	$textbox2.Location = '108, 61'
	$textbox2.Name = 'textbox2'
	$textbox2.Size = '271, 20'
	$textbox2.TabIndex = 4
	#
	# labelOutputFolder
	#
	$labelOutputFolder.AutoSize = $True
	$labelOutputFolder.Location = '12, 64'
	$labelOutputFolder.Name = 'labelOutputFolder'
	$labelOutputFolder.Size = '80, 17'
	$labelOutputFolder.TabIndex = 3
	$labelOutputFolder.Text = 'Output Folder: '
	$labelOutputFolder.UseCompatibleTextRendering = $True
	#
	# textbox1
	#
	$textbox1.Location = '108, 23'
	$textbox1.Name = 'textbox1'
	$textbox1.PasswordChar = '*'
	$textbox1.Size = '271, 20'
	$textbox1.TabIndex = 2
	#
	# labelEnterPassword
	#
	$labelEnterPassword.AutoSize = $True
	$labelEnterPassword.Location = '12, 26'
	$labelEnterPassword.Name = 'labelEnterPassword'
	$labelEnterPassword.Size = '90, 17'
	$labelEnterPassword.TabIndex = 1
	$labelEnterPassword.Text = 'Enter Password: '
	$labelEnterPassword.UseCompatibleTextRendering = $True
	#
	# buttonCreate
	#
	$buttonCreate.Anchor = 'Bottom, Right'
	$buttonCreate.DialogResult = 'OK'
	$buttonCreate.Location = '304, 115'
	$buttonCreate.Name = 'buttonCreate'
	$buttonCreate.Size = '75, 23'
	$buttonCreate.TabIndex = 0
	$buttonCreate.Text = '&Create'
	$buttonCreate.UseCompatibleTextRendering = $True
	$buttonCreate.UseVisualStyleBackColor = $True
	$buttonCreate.add_Click($buttonCreate_Click)
	$formSecurePassword.ResumeLayout()
	#endregion Generated Form Code
	
	#----------------------------------------------
	
	#Save the initial state of the form
	$InitialFormWindowState = $formSecurePassword.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$formSecurePassword.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$formSecurePassword.add_FormClosed($Form_Cleanup_FormClosed)
	#Show the Form
	return $formSecurePassword.ShowDialog()
	
} #End Function

#Call the form
Show-Paasword_Form_psf | Out-Null

