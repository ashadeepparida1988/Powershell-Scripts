﻿<# 
Description: Basic template script for unattached disk deletion.
#>

param(

$folderForLogFile = "C:\Temp\Results"

)

#region Functions #####

#Log File Function
function AddTo-LogFile {
param(

$message 

)    
try{
    
    Add-Content -Path $logFile -Value $message -Force
}
catch{
    
    $errorAddLog = "Error while writing to Log file - $($Error[0])"
    Write-Error $errorAddLog
}
}

#Function to delete unattached disks
function delete-azdisks {
param(

)
try{

    #Get list of existing unattached disks
    $existingUnattachedDisks = (Get-AzDisk | ?{$_.DiskState -eq "Unattached"})
    AddTo-LogFile "Existing Unattached Disks"
    AddTo-LogFile $existingUnattachedDisks.Name

    #Add Code to delete unattached disks based on agreed policy
    #Using Remove-AzDisk

}
catch{
    
    $errorDeletion = "Error while deleting unattached disks: $error[0]"
    AddTo-LogFile $errorDeletion
}

}

#endregion

#region Variables #####
try{

$datetime = Get-Date -Format "dd_MM_yy_hh_mm_ss"
$logFileName = "unattached_disk_delete_results_$($datetime).log"
New-Item -Path $folderForLogFile -Name $logFileName -ItemType File -Force | Out-Null

    if(Test-Path -Path "$($folderForLogFile)\$($logfileName)"){
    
        $logFile = "$($folderForLogFile)\$($logfileName)"
        "Log File Path: $logFile"
    
    }
    else{
    
        Write-Error "Unable to create log file."
        Exit
    }

}catch{

    Write-Error "Error in Variables Section: $($Error[0])"
    Exit
}
#endregion

#region Main #####

delete-azdisks

#endregion 