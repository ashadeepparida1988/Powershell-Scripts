﻿C:\Users\ravindraaz\Downloads\MMGReportsC:\Users\ravindraaz\Downloads\MMGReportsC:\Users\ravindraaz\OneDrive - HCL Technologies Ltd\ELASTIC OPS\BUCKET-D\MMG\ACCESSC:\Users\ravindraaz\OneDrive - HCL Technologies Ltd\ELASTIC OPS\BUCKET-D\MMG\ACCESSC:\Users\ravindraaz\OneDrive - HCL Technologies Ltd\ELASTIC OPS\BUCKET-D\MMG\ACCESS<#	
	.NOTES
	===========================================================================
	 Created with: 	PowerShell ISE
	 Created on:   	17 Nov 2020 
	 Created by:   	Rahul Sawant
     Email:         sawantrahul.sanjay@hcl.com
	 Organization: 	HCL Technologies
	 Project Name:	MMG
	 Filename:     	Azure-Disk-Size-Report.ps1
	 Version: 		2.0
	===========================================================================
	.DESCRIPTION
		Module - Azure AZ Latest Version
        This script is design to capture Disk Size report for all the subscriptions

    .INFO
        Version 1.0 - export csv file which contain all subscription disk sizes in GB or TB
        version 2.0 - export 2 csv files which contains all subscriptions disk sizes and disk details
#>

$ErrorActionPreference = 'Stop'

#region timestamp
$TimeStamp = Get-Date -Format dddd-ddMMM-hhmmtt
$startTime = (Get-Date)
$FileName1 = "AzureTotalDiskSizeReport"
$FileName2 = "AzureDiskReport"

#endregion

#region select folder
do
{
    $TargetFolder1 = Read-Host "Enter Target Folder to save Output"
    $global:TargetFolder = $TargetFolder1.Replace('"', '')
}
until (Test-Path $TargetFolder)
$OutputFile = $TargetFolder + "\" + $FileName1 + "-" + $TimeStamp + ".csv"
$OutputFile_DiskReport = $TargetFolder + "\" + $FileName2 + "-" + $TimeStamp + ".csv"
#endregion

#region TimeStamp
function Get-TimeStamp
{
    [CmdletBinding()]
    param ()
    return "[{0:MM/dd/yyyy} {0:HH:mm:ss}]" -f (Get-Date)
}
#endregion

#region create class
class diskdatabase
{
    [string]$SubscriptionName
    [String]$SubscriptionId
    [String]$DiskSizeGB
    [String]$DiskSizeTB
    [String]$TotalDiskCount
    [String]$ConvertionType
}
#endregion

#region Connection to Azure Account
Write-Host "$(Get-TimeStamp) Connecting to Azure account. Please wait" -ForegroundColor Yellow
$null = Login-AzAccount -ErrorAction Stop
#endregion

#region Capturing total subscriptions
$total_subs = Get-AzSubscription -ErrorAction Stop
Write-Host "$(Get-TimeStamp) Total Subscription detected " -ForegroundColor Yellow -NoNewline
Write-Host $total_subs.Count -ForegroundColor Green
#endregion

$Azure_Disk_Database = $null
$capture_all_disks = $null
$Azure_Disk_Database = @()

$T = 1
#region Selecting Subscription
foreach ($sub in $total_subs)
{
    try
    {
        Write-Host "$(Get-TimeStamp) Selecting Subscription [$T] "  -ForegroundColor Yellow -NoNewline
        Write-Host $sub.Name -ForegroundColor Green
        $null = Select-AzSubscription -SubscriptionId $sub.SubscriptionId -ErrorAction Stop
        Write-Host "$(Get-TimeStamp) Subscription Selected Successfully " -ForegroundColor Yellow
    }
    catch
    {
        Write-Host "$(Get-TimeStamp) Failed to select Subscription " -ForegroundColor Red
        $_
    }

    #clearing variables
    $total_disks = $null
    $Disk_Size_GB = $null
    $Disk_Size_TB = $null

    #capturing total disk size details
    Write-Host "$(Get-TimeStamp) Capturing total Disks details " -ForegroundColor Yellow
    $total_disks = Get-AzDisk | Select-Object Name, ResourceGroupName, Location, OsType, ManagedBy, Sku, DiskSizeGB, TimeCreated, @{label="SubscriptionName";Expression={$sub.Name}}, @{label="SubscriptionId";Expression={$sub.SubscriptionId}} 
    $capture_all_disks += $total_disks

    if ($total_disks -eq $null)
    {
        $Disk_Size_GB = '0'
        $Disk_Size_TB = '0'
    }
    else
    {
        foreach ($item in $total_disks)
        {
            $Disk_Size_GB += $item.DiskSizeGB
        }

        $Disk_Size_TB = [System.Math]::Round(([string]$Disk_Size_GB + 'GB') / 1TB, 2)

        $Azure_Disk_Database += @([diskdatabase]@{
                SubscriptionName = ($sub.Name)
                SubscriptionId   = ($sub.SubscriptionId)
                DiskSizeGB       = ([string]$Disk_Size_GB)
                DiskSizeTB       = ([string]$Disk_Size_TB)
                TotalDiskCount   = ($total_disks.Count)
                ConvertionType   = 'In Binary'
            })
    }

    $T++
}

#region Saving outputfile
$Azure_Disk_Database | Export-Csv -Path $OutputFile -NoTypeInformation
Write-Host "$(Get-TimeStamp) File exported in " -NoNewline -ForegroundColor Yellow
Write-Host $OutputFile -ForegroundColor Green

$disk_details = $capture_all_disks | Select-Object Name, ResourceGroupName, Location,`
 @{label="VirtualMachine";Expression={if(($_.ManagedBy) -ne $null){($_.ManagedBy).split('/') | Select -Last 1}else{'NA'}}},`
 @{label="OSType";Expression={if($_.OsType -eq $null){'NA'}else{$_.OsType}}},`
  @{label="Sku";Expression={($_.Sku.Name)}}, DiskSizeGB, SubscriptionName, SubscriptionId, TimeCreated 

$disk_details | Export-Csv -Path $OutputFile_DiskReport -NoTypeInformation
Write-Host "$(Get-TimeStamp) File exported in " -NoNewline -ForegroundColor Yellow
Write-Host $OutputFile_DiskReport -ForegroundColor Green

$endTime = (Get-Date)
$ElapsedTime = ($endTime - $startTime)
$min = $ElapsedTime.Minutes
$sec = $ElapsedTime.Seconds
Write-Host "Script Completed in " -NoNewline
Write-Host "$min Minutes $sec Seconds " -ForegroundColor Green
#endregion

################################################## End of Script #################################################