﻿<# 
Description: Basic template script for snapshot deletion.
#>

param(

$folderForLogFile = "C:\Temp\Results"

)

#region Functions #####

function AddTo-LogFile {
param(

$message 

)    
try{
    
    Add-Content -Path $logFile -Value $message -Force
}
catch{
    
    $errorAddLog = "Error while writing to Log file - $($Error[0])"
    Write-Error $errorAddLog
}
}

function delete-snapshot {
param(

)
try{

    #Get list of snapshots
    $existingSnapshots = (Get-AzSnapshot)
    AddTo-LogFile "Existing Snapshots"
    AddTo-LogFile $existingSnapshots.Name

    #Add Code to delete snapshot based on agreed policy
    #Using Remove-AzSnapshot 

}
catch{
    
    $errorDeletion = "Error while deleting snapshots: $error[0]"
    AddTo-LogFile $errorDeletion
}

}

#endregion

#region Variables #####
try{

$datetime = Get-Date -Format "dd_MM_yy_hh_mm_ss"
$logFileName = "snapshot_delete_results_$($datetime).log"
New-Item -Path $folderForLogFile -Name $logFileName -ItemType File -Force | Out-Null

    if(Test-Path -Path "$($folderForLogFile)\$($logfileName)"){
    
        $logFile = "$($folderForLogFile)\$($logfileName)"
        "Log File Path: $logFile"
    
    }
    else{
    
        Write-Error "Unable to create log file."
        Exit
    }

}catch{

    Write-Error "Error in Variables Section: $($Error[0])"
    Exit
}
#endregion

#region Main #####

delete-snapshot

#endregion 