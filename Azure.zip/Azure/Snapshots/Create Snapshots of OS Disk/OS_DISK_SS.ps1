﻿<#
Requirements: 
1. Az Powershell Module
2. Azure account looged in via CLI. As of now we are not using service prinipal in the script.

Description: 
Script to take OD Disk Screenshot
1. Snapshot name will be like e.g. servername_chgnumber_OS_DISK_SS_26_5_2021
2. Snapshot created will have features: i) Resource Group and Location same as VM 
                                        ii) Encryption Type: EncryptionAtRestWithPlatformKey
                                        iii) Network access policy: Allow All
                                        iv) Snapshot type: 	Full - make a complete read-only copy of the selected disk.
                                        v) Storage type: Standard HDD

Variables:
1. pathToServers: Provide path to the text file containing list of servers for which OS Disksnapshot needs to be taken.
2. chgNumber:  Change number corresponding to the request to mention in the snapshot name while creating new snapshot.
3. differentSubscription: set this to yes if you want to use the non default subscription.
4. subscriptionId: Provide only in case of using non default subscription.

#>

param(
    
    #path to file containing list of servers.
    $pathToServers = "C:\Users\lovemasta.l\OneDrive - HCL Technologies Ltd\Documents\MMG\Servers.txt",

    #Change number for which snapshot will be created. 
    $chgNumber = "CHG0300075",

    #Switch for using non default subscription 
    $differentSubscription = "No",

    # Non default subscription Id
    $subscriptionId = ""
)



#region Functions
Function Take_Snapshot{

try{

foreach($server in $servers) {

            Write-Host "----- $server -----"
            #Snapshot name to be used
            $snapshotName = "$($server)_$($chgNumber)_OS_DISK_SS_$($todaysDate)"
            

            #fetch VMInfo
            $vmInfo = Get-AzVM -Name $server | select *
            if($vmInfo.count -gt 1){
            
                "Two VM's with same name $($server) found! Not creating any snapshot for this VM."
                Continue
            }   
            else{
                
                #Fetch Resource Group and VM Location
                $resourceGroup = $vmInfo.ResourceGroupName
                $location = $vmInfo.Location 
                
                #write information on the screen
                Write-Host "Server Name: $($server)"
                Write-Host "Resource Group Name: $($resourceGroup)" 
                Write-Host "Server Location: $($location)"
                Write-Host "OSDisk: $($vmInfo.StorageProfile.OsDisk.ManagedDisk.Id)"
                Write-Host "Snapshot name to be used: $($snapshotName)"
                $snapshotName >> $snapDate

                #Create Snapshot Config
                $snapshotConfig = New-AzSnapshotConfig -SourceUri $vmInfo.StorageProfile.OsDisk.ManagedDisk.Id -Location $location -EncryptionType EncryptionAtRestWithPlatformKey -NetworkAccessPolicy AllowAll -SkuName Standard_LRS -CreateOption copy
                
                #Take new snapshot 
                $newSnapshot = New-AzSnapshot -ResourceGroupName $resourceGroup -SnapshotName $snapshotName -Snapshot $snapshotConfig 
                
                do{ 
                    #Start-Sleep 5
                    #Get new snapshot state
                    $getNewSnap = Get-AzSnapshot -ResourceGroupName $resourceGroup -SnapshotName $snapshotName 
                    Write-Host "Provisioning state: $($getNewSnap.ProvisioningState)"
                    

                }while($getNewSnap.ProvisioningState -eq "InProgress")
                
                if($getNewSnap.ProvisioningState -eq "Succeeded"){
    
                    "Snapshot has been created successfully"
                    
                }
                    
                else{

                    "Snapshot creation failed for server:$($server)"
                
                }
            }

} 




}catch{
    
    Write-Error "Error while taking snapshot - $Error[0]. Exiting from the code."
    Exit

}

}
#endregion

#region Variables
$todaysDate = (get-date -Format "dd_MM_yyyy")
$servers = Get-Content -Path $pathToServers
$snapDate = "C:\Temp\snapshot_names_$(get-date -Format "dd_MM_yy_hh_mm_ss").txt"
#endregion

#region MAIN

try{

if($differentSubscription -eq "Yes"){
    
    Set-AzContext -Subscription $subscriptionId
    $checkSub = (Get-AzContext).Subscription
    if($checkSub -eq $subscriptionId){
        
        Write-Host "Context has been changed to new subscription: $($checkSub)"
    }
    else{
        
        Write-Host "Unable to change subscription! Try to run {set-azcontext -subscription subscriptionId} manually."
        Exit
    }
}

#Calling function to take snapshot
Take_Snapshot


}catch{

    Write-Host "Error in Main - $error[0]"
    Exit
}
#endregion

