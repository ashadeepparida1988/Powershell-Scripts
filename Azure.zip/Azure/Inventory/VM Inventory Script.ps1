﻿param(

    $todaysDate = (get-date -Format "dd_MM_yyyy_hh_mm_ss"),
    $pathtoLogFile = "C:\Program Files\geops\auto\results\logs\VM_Inventory_$todaysDate.log",
    $pathToExlFile = "C:\Program Files\geops\auto\results\Files\VM Inventory\MMG_Inventory_$todaysDate.csv"

)

#region Function

Function AddtoLogfile {
param(

$message

)
try{
    
    if((Test-Path -Path $pathToLogFile) -eq $false){
        
        New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType Directory -Force
        if((test-path -path (Split-Path -Path $pathToLogFile -Parent)) -eq $true){
        
            New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType File -Name (Split-Path -Path $pathToLogFile -Leaf) -Force
        }
    }else{
        
        if((Test-Path -Path $pathToLogFile ) -eq $false){
            
            New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType File -Name (Split-Path -Path $pathToLogFile -Leaf) -Force
        }
    }

    Add-Content -Value $message -Path $pathToLogFile -Force 

}catch{
    
    $errorLogging = "Error while logging - $($error[0].Message)"
    $errorLogging >> "$(Split-Path -Path $pathToLogFile -Parent)\loggingerror.txt"
}
    

}

Function LoginToAzure {
param(
)
try{
    
    $pass = get-content $jsonPath | ConvertTo-SecureString
    $creds = new-object system.management.automation.pscredential($inputsPath.email.from,$pass)

    Connect-AzAccount -Credential $creds

    $getSubscriptions = Get-AzSubscription
    if($getSubscriptions){
        
        AddtoLogfile "Login Successfull"
    }
    else{
        
        AddtoLogfile "Unable To Login - Please check Credentials"
    }


}catch{
    
    $errorLogin = "Error while login to azure - $($error[0].Message)"
    AddtoLogfile $errorLogin
    Exit
}
}

Function GetDiskSize ($DiskURI) 
{ 


  # User running the script must have Read access to the VM Storage Accounts for these values to be retreive
  $error.clear() 
  $DiskContainer = ($DiskURI.Split('/'))[3]  
  $DiskBlobName  = ($DiskURI.Split('/'))[4]  
 
  # Create Return PS object
  $BlobObject = @{'Name'=$DiskURI;'SkuName'=" ";'SkuTier'=" ";'DiskSize'=0}

  # Avoid connecting to Storage if last disk in same Storage Account (Save significant time!) 
  if ($global:DiskSA -ne ((($DiskURI).Split('/')[2]).Split('.'))[0]) 
  { 
    $global:DiskSA = ((($DiskURI).Split('/')[2]).Split('.'))[0] 
    $global:SAobj = $AllARMSAs | where-object {$_.StorageAccountName -eq $DiskSA} 
    $SARG  = $global:SAobj.ResourceGroupName 
    $SAKeys     = Get-AzStorageAccountKey -ResourceGroupName $SARG -Name $DiskSA 
    $global:SAContext  = New-AzStorageContext -StorageAccountName $DiskSA  -StorageAccountKey $SAKeys[0].value  
  } 

  $DiskObj = get-azstorageblob -Context $SAContext -Container $DiskContainer -Blob $DiskBlobName 
  if($Error) 
    {   
       $BlobObject.DiskSize = -1  
       $error.Clear() 
    } 
  else 
    { 
      [int] $DiskSize = $Diskobj.Length/1024/1024/1024 # GB
      $BlobObject.DiskSize = $DiskSize
      $BlobObject.SkuName = $global:SAobj.Sku.Name
      $BlobObject.SkuTier = $global:SAobj.Sku.Tier 
    }  
 
  Return $BlobObject  

  trap { 
      Return $BlobObject 
    } 
} 

Function sendMail{
param()

try{    
    #copy exl to new file
    $newExlPath = "$(Split-Path $pathToExlFile -Parent)\MMG Azure Inventory.csv"
    AddtoLogfile "Renaming Log file to new name: $newExlPath."
    Copy-Item -Path $pathToExlFile -Destination $newExlPath -Force
    if((Test-Path $newExlPath) -eq $true){
        
        AddtoLogfile "Rename successfull."
        
        $SMTPServer = $inputsPath.email.smtpServer 
        $To = $inputsPath.email.to 
        $from = $inputsPath.email.from 
        $attachment = $newExlPath
        $cc = $inputsPath.email.cc
        $body = "Please find attached latest MMG Azure Inventory."

        Send-MailMessage -smtpserver $SMTPServer -From $From -To $To -Cc $cc -Subject "MMG Azure Inventory" -Body $body -Attachments $attachment -BodyAsHtml
        if($? -eq $true){
            
            AddtoLogfile "Email sent successfully."

        }
        #remove exl file
        Remove-Item -Path $newExlPath -Force
        Sleep 30
        Remove-Item -Path $pathToExlFile -Force
    }
    else{
        
        AddtoLogfile "Unable to send email as log file is not renamed!"
        Sleep 30
        Remove-Item -Path $pathToExlFile -Force
    }

}catch{
    
    $mailError = "Error while sending email - $($error[0])"
    AddtoLogfile $mailError
}    

}
#endregion

#region Variables

#get current script path
$myScriptPath = $MyInvocation.MyCommand.Path
$jsonPath = "$(split-path $myScriptPath -Parent)\config.json"
$inputsPath = get-content "$(split-path $myScriptPath -Parent)\inputs.json" | ConvertFrom-Json
$locations = @()
$locations = $inputsPath.locations
#@("","" )
        

if((test-path -path $pathToExlFile) -eq $false){
    
    New-Item -Path $pathToExlFile -Force
    if((test-path -path $pathToExlFile) -eq $false){
        
        AddtoLogfile "Unable to Create Excel File - $($error[0])"
        Exit
    }
}

#endregion

#region Main


    AddtoLogfile "$(Get-Date -Format "dd_MM_yy_hh_mm_ss") - Script Start"
    AddtoLogfile "Get all Subscriptions"
    $Subscriptions = Get-AzSubscription
    $azureVmData = @()
    foreach($Subscription in $Subscriptions){
    
        AddtoLogfile "Set context to current subscription."
        Set-AzContext -Subscription $subscription.id
        AddtoLogfile "Context set to: $($Subscription.id)"
        
        AddtoLogfile "Fetching all Vm's"
        $AllVMs = Search-AzGraph -Query "Resources | where type =~ 'Microsoft.Compute/virtualMachines'" -First 1000 -Subscription $subscription.id
        AddtoLogfile "Total Vm's: $($AllVMs.count)"
        
        AddtoLogfile "Fetching other related resources"
        #get all Nics 
        $nics= Search-AzGraph -Query "Resources | where type =~ 'Microsoft.Network/networkInterfaces'" -First 1000 -Subscription $subscription.id

        #get all vnets
        $vnets = Search-AzGraph -Query "Resources | where type =~ 'Microsoft.Network/virtualNetworks'" -First 1000 -Subscription $subscription.id

        #get all public ip addresses
        $pubIps = Search-AzGraph -Query "Resources | where type =~ 'Microsoft.Network/publicIPAddresses'" -First 1000 -Subscription $subscription.id

        #get all availability sets
        $allAvs = Search-AzGraph -Query "Resources | where type =~ 'Microsoft.Compute/availabilitySets'" -First 1000 -Subscription $subscription.id
        
        #get all managed disks
        $allManagedDisks = Search-AzGraph -Query "Resources | where type =~ 'Microsoft.Compute/disks'" -First 1000 -Subscription $subscription.id

        #get all storage accounts
        $AllARMSAs = Search-AzGraph -Query "Resources | where type =~ 'Microsoft.Storage/storageAccounts'" -First 1000 -Subscription $subscription.id

        #get vm sizes with location
        $AllVMSizes = @()
        foreach($location in $locations){
    
            $vmSizeLoc = Get-AzVMSize -Location $location
            foreach($vmSize in $vmSizeLoc){
        
                if($AllVMSizes.Name -notcontains $vmSize.Name){$AllVMSizes += $vmSize}
            }

        }

        #get list of all tags
        $AllVMTags =  @() 
        foreach($vm in $AllVMs){

            $tags = ($vm.tags | get-member -MemberType NoteProperty)
            $tkeys = $tags.Name
            foreach($key in $tkeys){
    
                if($allVMtags -notcontains $key){$allVMtags += $key}
            }

        }
        AddtoLogfile "Total different tags count: $($AllVMTags.count)"
        $vmCount = 0
        
        
        foreach($vm in $AllVMs){
            
            $vmcount = $vmCount + 1
            AddtoLogfile $vmCount

            #Get Cores and Memory
            $vmCores = ""
            $vmMemory = ""
            $vmCores = ($AllVMSizes | ?{$_.Name -eq $vm.properties.hardwareProfile.vmSize}).NumberOfCores
            $vmMemory = ((($AllVMSizes | ?{$_.Name -eq $vm.properties.hardwareProfile.vmSize}).MemoryinMB)/1024).tostring() + " GB"

            #get License type
            $licenseType = "NA"
            if($vm.properties.licenseType -ne $null){
            
                $licenseType = "BYOL"
            }
            else{
            
                $licenseType = "PAYG"
            }


            #get availability set
            $availabilitySet = "None"
            foreach($avs in $allAvs){
        
                foreach($mid in $avs.properties.virtualmachines.id){
            
                    if($mid -eq $vm.id){
                
                        $availabilitySet = $avs.Name
                        break
                    }
                }
        
            }

            # Get VM OS Disk properties 
            $OSDiskName = '' 
            $OSDiskSize = 0
            $OSDiskRepl = '' 
            $OSDiskTier = ''
            $OSDiskHCache = ''  # Init/Reset

            # Get OS Disk Caching if set 
            $OSDiskHCache = $vm.properties.storageProfile.osDisk.caching

            # Check if OSDisk uses Storage Account
            if($vm.properties.StorageProfile.OsDisk.ManagedDisk -eq $null)
            {
                # Retreive OS Disk Replication Setting, tier (Standard or Premium) and Size 
                $VMOSDiskObj = GetDiskSize $vm.properties.StorageProfile.OsDisk.Vhd.uri
                $OSDiskName = $VMOSDiskObj.Name 
                $OSDiskSize = $VMOSDiskObj.DiskSize
                $OSDiskRepl = $VMOSDiskObj.SkuName 
                $OSDiskTier = "Unmanaged"
            }
            else
            {
                $OSDiskID = $vm.properties.StorageProfile.OsDisk.ManagedDisk.Id
                $VMOSDiskObj = $AllMAnagedDisks | where-object {$_.id -eq $OSDiskID }
                $OSDiskName = $VMOSDiskObj.Name 
                $OSDiskSize = $VMOSDiskObj.properties.DiskSizeGB 
                $OSDiskRepl = $VMOSDiskObj.sku.name
                $OSDiskTier = "Managed"
            }

            $AllVMDisksPremium = $true 
            if($OSDiskRepl -notmatch "Premium") { $AllVMDisksPremium = $false } 



            #Fetch Nic details
            $nicNames = @()
            $NICProvState = @()
            $NICPrivateIPs = @()
            $NICPrivateAllocationMethod = @()
            $NICSubnet = @()
            $nicvnet = @()
            foreach($nic in $vm.Properties.networkprofile.networkinterfaces){
    
                $matchingNic = $nics | ?{$_.id -eq $nic.id}
                $nicNames += $matchingNic.Name
                $NICProvState += $MatchingNic.properties.ProvisioningState
                $NICPrivateIPs += $MatchingNic.properties.IpConfigurations.properties.PrivateIpAddress 
                $NICPrivateAllocationMethod += $MatchingNic.properties.IpConfigurations.properties.PrivateIpAllocationMethod 
                $NICSubnetID = $MatchingNic.properties.IpConfigurations.properties.Subnet.Id 
    
                $vmvnet = $vnets | where-object {$_.properties.Subnets.id -eq $NICSubnetID } 
                $NICVnet += $vmvnet.Name 

                # Identifying the VM subnet 
                $AllVNetSubnets = $VMVNet.properties.subnets
                $vmSubnet = $AllVNetSubnets | where-object {$_.id -eq $NICSubnetID }  
                $NICSubnet += $vmSubnet.Name 

                # Identifying Public IP Address assigned 
                $VMPublicIPID = $MatchingNic.properties.IpConfigurations.properties.PublicIpAddress.Id 
                $VMPublicIP = $pubIps | where-object {$_.id -eq $VMPublicIPID } 
                $NICPublicIP = $VMPublicIP.properties.ipAddress
                $NICPublicAllocationMethod = $VMPublicIP.properties.publicIPAllocationMethod
 
 
            }

            # Get VM Data Disks and their properties 
            $DataDiskObj = @()
            $VMDataDisksObj = @() 
            # Intitialize Storage Account Context variable 
            $global:DiskSA = "" 
        
            foreach($DataDisk in $vm.properties.StorageProfile.DataDisks) 
            { 

                # Initialize variable before each iteration
                $VMDataDiskName = ''
                $VMDataDiskSize = 0
                $VMDataDiskRepl = ''
                $VMDataDiskTier = ''
                $VMDataDiskHCache = '' # Init/Reset 

                # Get Data Disk Caching if set 
                $VMDataDiskHCache = $DataDisk.Caching
              
                # Check if this DataDisk uses Storage Account
                if($DataDisk.ManagedDisk -eq $null)
                              {
                    # Retreive OS Disk Replication Setting, tier (Standard or Premium) and Size 
                    $VMDataDiskObj = GetDiskSize $DataDisk.vhd.uri 
                    $VMDataDiskName = $VMDataDiskObj.Name
                    $VMDataDiskSize = $VMDataDiskObj.DiskSize
                    $VMDataDiskRepl = $VMDataDiskObj.SkuName
                    $VMDataDiskTier = "Unmanaged"
                }
                else
                {
                    $DataDiskID = $DataDisk.ManagedDisk.Id
                    $VMDataDiskObj = $allManagedDisks | where-object {$_.id -eq $DataDiskID }
                    $VMDataDiskName = $VMDataDiskObj.Name
                    $VMDataDiskSize = $VMDataDiskObj.properties.DiskSizeGB
                    $VMDataDiskRepl = $VMDataDiskObj.sku.name
                    $VMDataDiskTier = "Managed"
                }


                # Add Data Disk properties to arrray of Data disks object
                $DataDiskObj += @([pscustomobject]@{'Name'=$VMDataDiskName;'HostCache'=$VMDataDiskHCache;'Size'=$VMDataDiskSize;'Repl'=$VMDataDiskRepl;'Tier'=$VMDataDiskTier})

                # Check if this datadisk is a premium disk.  If not, set the all Premium disks to false (No SLA)
                if($VMDataDiskRepl -notmatch "Premium") { $AllVMDisksPremium = $false } 
            }

            #get tag getails
            $tagObj = @()
            $thisVmTags = ($Vm.tags | get-member -MemberType NoteProperty)
            :outer foreach($tag in $allVMtags){
                $check = 0
                foreach($vmTag in $thisVmTags){
            
                    if($vmTag.Name -eq $tag){
                
                        $check = 1
                        $tagObj += [pscustomobject]@{
                    
                        $tag = ($vmTag.Definition -split "=")[-1]
                    
                        }
                        continue outer
                    }
            
                }
                if($check -eq 0){
            
                    $tagObj += [pscustomobject]@{
                    
                        $tag = ""
                    
                    }
                }
            }
         
            
            $azureVmData += [pscustomobject]@{
                            
                            "Subscription" = $Subscription.Name
                            "Resource Group" = $vm.resourceGroup 
                            "Location" = $vm.location
                            "Virtual Machine" = $vm.name
                            "Status" = ($vm.properties.extended.instanceView.powerState | select -First 1).displayStatus
                            "Availability Zone" = $vm.zones
                            "Availability Set" = $availabilitySet
                            "Size" = $vm.properties.hardwareProfile.vmSize
                            "No. Of Cores" = $vmCores
                            "Memory" = $vmMemory
                            "OS Type" = $vm.properties.storageProfile.osDisk.osType
                            "License Type" = $licenseType
                            "Network Interfaces" = $nicNames -join ","
                            "NIC Provisioning State" = $NICProvState -join ","
                            "Private IPs" = $NICPrivateIPs -join ","
                            "Private IP Allocation" = $NICPrivateAllocationMethod -join ","
                            "Virtual Network" = $nicvnet -join ","
                            "Subnet" = $NICSubnet -join ","
                            "Public IPs" = $NICPublicIP
                            "Public IP Allocation" = $NICPublicAllocationMethod
                            "Instance SLA" = $AllVMDisksPremium
                            "OS Disk" = $OSDiskName 
                            "OS Disk Cache" = $OSDiskHCache
                            "OS Disk Size" = $OSDiskSize
                            "OS Disk Tier" = $OSDiskTier  
                            "OS Disk Replication" = $OSDiskRepl 
                            "Data Disks" = $DataDiskObj.Name -join "," 
                            "Data Disks Cache" = $DataDiskObj.HostCache -join "," 
                            "Data Disks Size in GB" = $DataDiskObj.Size -join "," 
                            "Data Disks Tier" = $DataDiskObj.Tier -join ","
                            "Data Disks Replication" = $DataDiskObj.Repl -join ","
                            ((($tagObj)[0] -split "=")[0] -split "{")[1] = ((($tagObj)[0] -split "=")[1] -split "}")[0]
                            ((($tagObj)[1] -split "=")[0] -split "{")[1] = ((($tagObj)[1] -split "=")[1] -split "}")[0]
                            ((($tagObj)[2] -split "=")[0] -split "{")[1] = ((($tagObj)[2] -split "=")[1] -split "}")[0]
                            ((($tagObj)[3] -split "=")[0] -split "{")[1] = ((($tagObj)[3] -split "=")[1] -split "}")[0]
                            ((($tagObj)[4] -split "=")[0] -split "{")[1] = ((($tagObj)[4] -split "=")[1] -split "}")[0]
                            ((($tagObj)[5] -split "=")[0] -split "{")[1] = ((($tagObj)[5] -split "=")[1] -split "}")[0]
                            ((($tagObj)[6] -split "=")[0] -split "{")[1] = ((($tagObj)[6] -split "=")[1] -split "}")[0]
                            ((($tagObj)[7] -split "=")[0] -split "{")[1] = ((($tagObj)[7] -split "=")[1] -split "}")[0]
                            ((($tagObj)[8] -split "=")[0] -split "{")[1] = ((($tagObj)[8] -split "=")[1] -split "}")[0]
                            ((($tagObj)[9] -split "=")[0] -split "{")[1] = ((($tagObj)[9] -split "=")[1] -split "}")[0]
                            ((($tagObj)[10] -split "=")[0] -split "{")[1] = ((($tagObj)[10] -split "=")[1] -split "}")[0]
                            ((($tagObj)[11] -split "=")[0] -split "{")[1] = ((($tagObj)[11] -split "=")[1] -split "}")[0]
                            ((($tagObj)[12] -split "=")[0] -split "{")[1] = ((($tagObj)[12] -split "=")[1] -split "}")[0]
                            ((($tagObj)[13] -split "=")[0] -split "{")[1] = ((($tagObj)[13] -split "=")[1] -split "}")[0]
                            ((($tagObj)[14] -split "=")[0] -split "{")[1] = ((($tagObj)[14] -split "=")[1] -split "}")[0]
                            ((($tagObj)[15] -split "=")[0] -split "{")[1] = ((($tagObj)[15] -split "=")[1] -split "}")[0]
                            ((($tagObj)[16] -split "=")[0] -split "{")[1] = ((($tagObj)[16] -split "=")[1] -split "}")[0]
                            ((($tagObj)[17] -split "=")[0] -split "{")[1] = ((($tagObj)[17] -split "=")[1] -split "}")[0]
                            ((($tagObj)[18] -split "=")[0] -split "{")[1] = ((($tagObj)[18] -split "=")[1] -split "}")[0]
                            ((($tagObj)[19] -split "=")[0] -split "{")[1] = ((($tagObj)[19] -split "=")[1] -split "}")[0]
                            ((($tagObj)[20] -split "=")[0] -split "{")[1] = ((($tagObj)[20] -split "=")[1] -split "}")[0]
                            ((($tagObj)[21] -split "=")[0] -split "{")[1] = ((($tagObj)[21] -split "=")[1] -split "}")[0]
                            ((($tagObj)[22] -split "=")[0] -split "{")[1] = ((($tagObj)[22] -split "=")[1] -split "}")[0]
                            ((($tagObj)[23] -split "=")[0] -split "{")[1] = ((($tagObj)[23] -split "=")[1] -split "}")[0]
                            ((($tagObj)[24] -split "=")[0] -split "{")[1] = ((($tagObj)[24] -split "=")[1] -split "}")[0]
                            ((($tagObj)[25] -split "=")[0] -split "{")[1] = ((($tagObj)[25] -split "=")[1] -split "}")[0]
                            #>
                             
                    } 



        }#vm foreach end 

    }#sub foreach end

AddtoLogfile "Data fetch successfull, adding data to file"
$azureVmData | Export-Csv -Path $pathToExlFile -Force -NoTypeInformation

AddtoLogfile "Preparing to send email."
sendMail

AddtoLogfile "$(Get-Date -Format "dd_MM_yy_hh_mm_ss") - Script Start"


#endregion


