﻿<# 
Description: Basic template script for unattached network interface deletion deletion.
#>

param(

$folderForLogFile = "C:\Temp\Results"

)

#region Functions #####

#Log File Function
function AddTo-LogFile {
param(

$message 

)    
try{
    
    Add-Content -Path $logFile -Value $message -Force
}
catch{
    
    $errorAddLog = "Error while writing to Log file - $($Error[0])"
    Write-Error $errorAddLog
}
}

#Function to delete unattached nics
function delete-aznics {
param(

)
try{

    #Get list of existing unattached nics
    $existingUnattachednics = (Get-AzNetworkInterface | ?{$_.VirtualMachine -eq $null })
    AddTo-LogFile "Existing Unattached Nics"
    AddTo-LogFile $existingUnattachednics.Name

    #Add Code to delete unattached nics based on agreed policy
    #Remove-AzNetworkInterface

}
catch{
    
    $errorDeletion = "Error while deleting unattached nics: $error[0]"
    AddTo-LogFile $errorDeletion
}

}

#endregion

#region Variables #####
try{

$datetime = Get-Date -Format "dd_MM_yy_hh_mm_ss"
$logFileName = "unattached_nic_delete_results_$($datetime).log"
New-Item -Path $folderForLogFile -Name $logFileName -ItemType File -Force | Out-Null

    if(Test-Path -Path "$($folderForLogFile)\$($logfileName)"){
    
        $logFile = "$($folderForLogFile)\$($logfileName)"
        "Log File Path: $logFile"
    
    }
    else{
    
        Write-Error "Unable to create log file."
        Exit
    }

}catch{

    Write-Error "Error in Variables Section: $($Error[0])"
    Exit
}
#endregion

#region Main #####

delete-aznics

#endregion 