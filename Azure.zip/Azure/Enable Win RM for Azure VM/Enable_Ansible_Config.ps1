﻿param()

#####
#region Function
#####
Function AddtoLogfile {
param(

$message

)
try{
    
    if((Test-Path -Path $pathToLogFile) -eq $false){
        
        New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType Directory -Force
        if((test-path -path (Split-Path -Path $pathToLogFile -Parent)) -eq $true){
        
            New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType File -Name (Split-Path -Path $pathToLogFile -Leaf) -Force
        }
    }else{
        
        if((Test-Path -Path $pathToLogFile ) -eq $false){
            
            New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType File -Name (Split-Path -Path $pathToLogFile -Leaf) -Force
        }
    }

    Add-Content -Value $message -Path $pathToLogFile -Force 

}catch{
    
    $errorLogging = "Error while logging - $($error[0].Message)"
    $errorLogging >> "$(Split-Path -Path $pathToLogFile -Parent)\loggingerror.txt"
}
    

}

Function LoginToAzure {
param(
)
try{
    
    #$pass = get-content $jsonPath | ConvertTo-SecureString
    $StoredCreds = Get-StoredCredential -Target "DBCheques"
    #$creds = new-object system.management.automation.pscredential($inputsPath.email.from,$pass)

    Connect-AzAccount -Credential $StoredCreds

    $getSubscriptions = Get-AzSubscription
    if($getSubscriptions){
        
        AddtoLogfile "Login Successfull"
    }
    else{
        
        AddtoLogfile "Unable To Login - Please check Credentials"
    }


}catch{
    
    $errorLogin = "Error while login to azure - $($error[0])"
    AddtoLogfile $errorLogin
    Exit
}
}

Function Invoke-CommandOnVM{
param()
    
    AddtoLogfile "Importing list of servers and resource group"
    $scriptResult = @()
    $serversList = Search-AzGraph -Query "Resources | where type =~ 'Microsoft.Compute/virtualMachines'" -First 1000 -Subscription $subscription.Id 
    AddtoLogfile "Total Servers: $($serversList.Count)"
    $servers = $serversList | ?{$_.properties.StorageProfile.osDisk.osType -eq "Windows"}
    AddtoLogfile "Total Windows Servers : $($servers.Count)"
    foreach($server in $servers){
        
        AddtoLogfile "$(get-date -Format "dd_MMM_yy_hh_mm_ss") - Running Script on server $($server.Name)"
        #$result = Invoke-AzVMRunCommand -ScriptPath $ScriptPath -ResourceGroupName $server.ResourceGroup -VMName $server.Name -CommandId 'RunPowerShellScript' 
        AddtoLogfile "Execution Status: $($result.status)"

        $scriptResult += [pscustomobject]@{
                            
                            "Subscription" = $subscription.Name
                            "Resource Group" = $server.ResourceGroup
                            "Server Name" = $server.Name
                            "Execution Status" = $result.Status
                            "StdOut Status" = $result.Value[0].DisplayStatus
                            "StdOut Message" = $result.Value[0].Message
                            "StdErr Status" = $result.Value[1].DisplayStatus
                            "StdErr Message" = $result.Value[1].Message
                            "Output Details" = $result.Output
                            "Error Details" = $result.Error
                            

                        }

    }

    $scriptResult | Export-Csv -Path "$(split-path $myScriptPath -Parent)\$($subscription.id)_result_$(Get-Date -Format "dd_MMM_yyyy_hh_mm_ss").csv" -Force -NoTypeInformation -Delimiter "," 

}
#endregion

#####
#region Variables
#####
#get current script path
$myScriptPath = $MyInvocation.MyCommand.Path
$todaysDate = (get-date -Format "dd_MMM_yyyy_hh_mm_ss")
#$inputsPath = "$myScriptPath\listofservers.csv"
#$jsonPath = "$(split-path $myScriptPath -Parent)\config.json"
$pathTologFile = "$(split-path $myScriptPath -Parent)\ansible_config_$($todaysDate).log"
#$ScriptPath = "$(split-path $myScriptPath -Parent)\ansible_winrm_enabling_Updated.ps1"

#endregion

#####
#region Main
#####

AddtoLogfile "Script Starts - $(Get-Date -Format "dd_MMM_yyyy_hh_mm_ss")"
LoginToAzure

AddtoLogfile "Preparing to invoke command on windows vm's"
$subscriptions = Get-AzSubscription
foreach($subscription in $subscriptions){
    
    AddtoLogfile "Setting context to subscription $($subscription.Name)"
    Set-AzContext -Subscription $subscription.Id
    Invoke-CommandOnVM
}

AddtoLogfile "Script Ends - $(Get-Date -Format "dd_MMM_yyyy_hh_mm_ss")"

#endregion