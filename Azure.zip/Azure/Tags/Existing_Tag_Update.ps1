﻿param(
    
    #Path to your csv file
    $pathToTagFile = "C:\Users\lovemasta.l\OneDrive - HCL Technologies Ltd\Documents\MMG\Scripts\Tags\Tags_Update.csv",
    
    #Path to Log File
    $folderForLogFile = "C:\Temp"

)

$ErrorActionPreference = "Continue"
#region Functions #####

function Update-ExistingTags {

try{

    # Start updating tags
    $tagsList | foreach{
    
    $server = $_.Server

    #Prints server name on output
    addto-logfile "----- $($server) -----"
    $vmInfo = get-azvm -Name $_.Server | select *

        if($vm.count -gt 1){
    
            AddTo-LogFile "Two VM's with same name $($server) found." -ErrorAction SilentlyContinue
            continue

        }
        else{
            
            $resourceGroupName = $vmInfo.ResourceGroupName
            AddTo-LogFile "VM's Resource Group Name: $resourceGroupName"
            
            $currentTags = $vmInfo.tags
            AddTo-LogFile "Curren Tags"
            AddTo-LogFile "$($currentTags | ConvertTo-Json)"
            
            $currentTags.'ApplicationOwner' = $_.'Application Owner'
            $currentTags.'ServerOwner' = $_.'Service Owner'
            $newTags = $currentTags
            AddTo-LogFile "New Tags"
            AddTo-LogFile "$($newTags| convertto-json)"
            #Set-AzResource -ResourceName $_.Server -ResourceGroupName $resourceGroupName -Tag $newTags
        }
    }

}
catch{

    $errorMessage = "Error while updating tags - $Error[0]"
    AddTo-LogFile    $errorMessage
}
    

}

function AddTo-LogFile {
param(

$message 

)    

Add-Content -Path $logFile -Value $message -Force

}
#endregion

#region Variables #####
$datetime = $(Get-Date -Format "dd_MM_yy_hh_mm_ss")
$logFileName = "update_existing_tags_$($datetime).log"

New-Item -Path $folderForLogFile -Name $logFileName -ItemType File -Force | Out-Null

if(Test-Path -Path "$($folderForLogFile)\$($logfileName)"){
    
    $logFile = "$($folderForLogFile)\$($logfileName)"
    "Log File Path: $logFile"
    
    $tagsList = Import-Csv -Path $pathToTagFile
    
}
else{
    
    Write-Error "Unable to create log file."
    Exit
}


#endregion

#region Main #####

Update-ExistingTags

#endregion 


