﻿param(
    
    #Mention Required Paarameters
    $folderForLogFile = "C:\Temp\Results"

)


#region Functions #####

function AddTo-LogFile {
param(

$message 

)    
try{
    
    Add-Content -Path $logFile -Value $message -Force
}
catch{
    
    $errorAddLog = "Error while writing to Log file - $($Error[0])"
    Write-Error $errorAddLog
}
}

function Get-AzVMBackupStatus {

param(

)
try{
    
    #Get Recovery Vaults
    $results = @()
    $totalSuccessful = 0
    $totalFailed = 0
    $totalInProgress = 0
    $vaults = Get-AzRecoveryServicesVault

    foreach($vault in $vaults){
    
        "----- $($vault.Name) -----"
        $vaultBackupJobs = Get-AzRecoveryServicesBackupJob -VaultId $vault.id -From (Get-Date).AddDays(-1).ToUniversalTime() -BackupManagementType AzureVM
        foreach($job in $vaultBackupJobs){
        
            "----- $($job.WorkloadName) -----"
            $job.Status
            if($job.Status -eq "Completed"){
            
                $totalSuccessful = $totalSuccessful + 1 
            }
        
            if($job.Status -eq "InProgress"){
            
                $totalInProgress = $totalInProgress + 1 
            }

            if($job.Status -eq "Failed"){
            
                $totalFailed = $totalFailed + 1 
            }

            $customObject = [PSCustomObject]@{

                "Server Name" = $job.WorkloadName
                "Vault Name" = $vault.Name
                "Job Status" = $job.Status
                "Start Time" = $job.StartTime
                "End Time" = $job.EndTime
    
            }
            $results += $customObject
        
        }

    }


    #Final Status
    $results | export-csv -Path "C:\temp\results.csv" -NoTypeInformation
    "Total Successful : $($totalSuccessful)"
    "Total Failed:  $($totalFailed)"
    "Total InProgress: $($totalInProgress)"
}
catch{
    
    $errorDeletion = "Error while fetching backup status: $error[0]"
    AddTo-LogFile $errorDeletion
}

}

#endregion

#region Variables #####

try{

$datetime = Get-Date -Format "dd_MM_yy_hh_mm_ss"
$logFileName = "VM_Backup_Job_Status_$($datetime).log"
New-Item -Path $folderForLogFile -Name $logFileName -ItemType File -Force | Out-Null

    if(Test-Path -Path "$($folderForLogFile)\$($logfileName)"){
    
        $logFile = "$($folderForLogFile)\$($logfileName)"
        "Log File Path: $logFile"
    
    }
    else{
    
        Write-Error "Unable to create log file."
        Exit
    }

}catch{

    Write-Error "Error in Variables Section: $($Error[0])"
    Exit
}

#endregion

#region Main #####
Get-AzVMBackupStatus
#endregion