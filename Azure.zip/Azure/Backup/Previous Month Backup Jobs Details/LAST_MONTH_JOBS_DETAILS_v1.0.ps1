﻿param(
    
    $todaysDate = (get-date -Format "dd_MM_yyyy_hh_mm_ss"),
    $pathtoLogFile = "C:\Temp\Logs\Backup\Logs\Previous_Month_Jobs_$todaysDate.log",
    $pathToExlFile = "C:\Temp\Logs\Backup\Files\Previous Month Backup Jobs\Previous_Month_Jobs_Details_$todaysDate.csv"
)

#region FUNCTIONS

Function AddtoLogfile {
param(

$message

)
try{
    
    if((Test-Path -Path $pathToLogFile) -eq $false){
        
        New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType Directory -Force
        if((test-path -path (Split-Path -Path $pathToLogFile -Parent)) -eq $true){
        
            New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType File -Name (Split-Path -Path $pathToLogFile -Leaf) -Force
        }
    }else{
        
        if((Test-Path -Path $pathToLogFile ) -eq $false){
            
            New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType File -Name (Split-Path -Path $pathToLogFile -Leaf) -Force
        }
    }

    Add-Content -Value $message -Path $pathToLogFile -Force 

}catch{
    
    $errorLogging = "Error while logging - $($error[0].Message)"
    $errorLogging >> "$(Split-Path -Path $pathToLogFile -Parent)\loggingerror.txt"
}
    

}



Function LoginToAzure {
param(
)
try{
    
    Connect-AzAccount
    $getSubscriptions = Get-AzSubscription
    if($getSubscriptions){
        
        AddtoLogfile "Login Successfull"
    }
    else{
        
        AddtoLogfile "Unable To Login - Please check Credentials"
    }


}catch{
    
    $errorLogin = "Error while login to azure - $($error[0].Message)"
    AddtoLogfile $errorLogin
    Exit
}
}

Function getLastMonthJobs {
param(
)    
try{
    
    $vaultData = @()    
    # get dates for last month
    $lastMonthFirstDay = $null
    $lastMonthLastDay = $null
    $lastMonthLastDayStart = $null
    $lastMonthLastDayEnd = $null

    $currentTime = [system.datetime]::UtcNow
    $lastMonth = (Get-DAte $currentTime -Hour 0 -Minute 0 -Second 0 ).AddMonths(-1)
    $lastMonthFirstDay = get-date $lastMonth -Day 1
    $lastMonthLastDay = GET-DATE $lastMonthFirstDay.AddMonths(1).AddSeconds(-1)
    if($lastMonthLastDay.Day -eq "31"){
            
           $lastMonthLastDay = GET-DATE $lastMonthLastDay.AddDays(-1)
           $lastMonthLastDayStart = get-date $lastMonth -Day 31 -Hour 0 -Minute 0 -Second 0
           $lastMonthLastDayEnd = (Get-Date $lastMonth -Day 31).AddDays(1).AddSeconds(-1)
    }
    
    AddtoLogfile "Fetching Jobs between $($lastMonthFirstDay) and $(if((GET-DATE $lastMonthFirstDay.AddMonths(1).AddSeconds(-1)).Day -eq "31"){$lastMonthLastDayEnd}else{$lastMonthLastDay})"

    $allLMJobs = Get-AzRecoveryServicesBackupJob -From $lastMonthFirstDay -To $lastMonthLastDay -BackupManagementType AzureVM -VaultId $vault.Id 
    addtologfile "Total Last Month Jobs: $($allLMJobs.Count)"
    foreach($job in $allLMJobs){
            
            #"JobId: $($job.JobId)"
            $vaultData += [pscustomobject]@{
                
                        "Subscription Name" = $subscription.Name
                        "vault Name" = $vault.Name
                        "Resource Group Name" = $vault.ResourceGroupName
                        "Virtual Machine" = $job.WorkloadName
                        "Job ID" = $job.jobid
			            "Operation" = $job.Operation
			            "Status" = $job.Status
			            "Start Time" = $job.StartTime
			            "End Time" = $job.EndTime
			            "Duration" = $job.Duration.tostring()
			            "Backup Management Type" = $job.BackupManagementType
  			            "Error Code" = $job.ErrorDetails.ErrorCode
                        "Error Message" = $job.ErrorDetails.ErrorMEssage
                        "Recommendations" = $job.ErrorDetails.Recommendations

            }
    }

    if($lastMonthLastDayStart){
            
            $allLastDayJobs = Get-AzRecoveryServicesBackupJob -From $lastMonthLastDayStart -To $lastMonthLastDayEnd -BackupManagementType AzureVM -VaultId $vault.Id
            AddtoLogfile "Total 31st Day Jobs: $($allLastDayJobs.Count)"         
            foreach($job in $allLastDayJobs){
            
            #"Last Day JobId: $($job.JobId)"
            $vaultData += [pscustomobject]@{
                
                        "Subscription Name" = $subscription.Name
                        "vault Name" = $vault.Name
                        "Resource Group Name" = $vault.ResourceGroupName
                        "Virtual Machine" = $job.WorkloadName
                        "Job ID" = $job.jobid
			            "Operation" = $job.Operation
			            "Status" = $job.Status
			            "Start Time" = $job.StartTime
			            "End Time" = $job.EndTime
			            "Duration" = $job.Duration.tostring()
			            "Backup Management Type" = $job.BackupManagementType
  			            "Error Details" = $job.ErrorDetails

            }
         }

    }


    #Adding Jobs Data to CSV
    $vaultData | Export-Csv -Path $pathToExlFile -NoTypeInformation -Append -force


}catch{
    
    $errorLM = "Error While Getting Last Three Weeks Jobs Data: $($error[0].Message)"
    AddtoLogfile $errorLM
    Exit
}
}
#endregion

#region VARIABLES
if((test-path -path $pathToExlFile) -eq $false){
    
    New-Item -Path $pathToExlFile -Force
    if((test-path -path $pathToExlFile) -eq $false){
        
        AddtoLogfile "Unable to Create Excel File - $($error[0])"
        Exit
    }
}
#endregion

#region MAIN
try{

    $allSubscriptions = Get-AzSubscription
    foreach($Subscription in $allSubscriptions){
    
        Set-AzContext -Subscription $Subscription.Id
        AddtoLogfile "Context set to Subscription: $($Subscription.Name)"

        AddtoLogfile "Getting List of all Vaults in subscription: $($Subscription.Name)"
        $allVaults = Get-AzRecoveryServicesVault

        AddtoLogfile "Total Vaults: $($allVaults.Count)"
        foreach($vault in $allVaults){
        
            AddtoLogfile "Vault Name: $($vault.Name)"
            getLastMonthJobs
        }
    }
}catch{
    
    $errorMain = "Error in Main - $($Error[0].Message)"
    $errorMain
}
#endregion
