﻿param(
    
)

#region Functions
#####
Function AddtoLogfile {
param(

$message

)
try{
    
    if((Test-Path -Path $pathToLogFile) -eq $false){
        
        New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType Directory -Force
        if((test-path -path (Split-Path -Path $pathToLogFile -Parent)) -eq $true){
        
            New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType File -Name (Split-Path -Path $pathToLogFile -Leaf) -Force
        }
    }else{
        
        if((Test-Path -Path $pathToLogFile ) -eq $false){
            
            New-Item -Path (Split-Path -Path $pathToLogFile -Parent) -ItemType File -Name (Split-Path -Path $pathToLogFile -Leaf) -Force
        }
    }

    Add-Content -Value $message -Path $pathToLogFile -Force 

}catch{
    
    $errorLogging = "Error while logging - $($error[0].Message)"
    $errorLogging >> "$(Split-Path -Path $pathToLogFile -Parent)\loggingerror.txt"
}
    

}

Function LoginToAzure {
param(
)
try{
    
    $pass = get-content $jsonPath | ConvertTo-SecureString
    $creds = new-object system.management.automation.pscredential($($inputsPath.email.from),$pass)

    Connect-AzAccount -Credential $creds

    $getSubscriptions = Get-AzSubscription
    if($getSubscriptions){
        
        AddtoLogfile "Login Successfull"
    }
    else{
        
        AddtoLogfile "Unable To Login - Please check Credentials"
    }


}catch{
    
    $errorLogin = "Error while login to azure - $($error[0].Message)"
    AddtoLogfile $errorLogin
    Exit
}
}

Function RemoveOldData {
param()
try{
    
    #get date to be deleted
    $todaysDate = Get-Date -Hour 0 -Minute 0 -Second 0
    $dateToBeDeleted = get-date $todaysDate.AddDays(-21) 
    #-Format "dd-MM-yyyy"

    #import the CSV
    $importedCsv = Import-Csv -Path $pathToCsvFile -Delimiter ","

    #transfer to new file
    foreach($line in $importedCsv){
        
        if(((get-date $line.Date) -lt $dateToBeDeleted) -or ((get-date $line.Date) -eq (get-date $todaysDate))){
                        
            #AddtoLogfile "Line Will be delted"
        }
        else{
            
            $line | export-csv -Path $pathToNewCSV -Force -NoTypeInformation -Append
        }
    }
        

}catch{
    
    $errorOldData = "Error while removing old data - $error[0]"
    AddtoLogfile $errorOldData
    Exit
}

}

Function VaultUsage {
param(
)

try{
    
    #get all vaults
    $vaults = Get-AzRecoveryServicesVault
    $VaultData = @()
    foreach($vault in $vaults){
        
        
        $VaultName = $vault.Name
        $VaultResourceGroup = $vault.resourcegroupname
        $URI = "https://management.azure.com/Subscriptions/$($Subscription.Id)/resourceGroups/$($vault.resourcegroupname)/providers/Microsoft.RecoveryServices/vaults/$($vault.Name)/usages"
        $URI = $URI + "?api-version=$apiVersion"

        AddtoLogfile "Sending request for the vault $($VaultName)"
        $Response = Invoke-RestMethod -Method GET -Uri $URI -Headers $authHeader -ContentType "application/json"
			
		if($Response -ne $null){	
            
            
            AddtoLogfile "Response received for the vault $($VaultName)"
            $Response.value | ForEach-Object{
							
							[String]$Key = $_.Name.Value
							$Value = $_.CurrentValue
							
							Switch($Key)
							{
								"ProtectedItemCount" {$ProtectedItemCount = $Value; break }
								"InProgressJobsCount" {$InProgressJobsCount = $Value; break }
								"FailedJobsCount" {$FailedJobsCount = $Value; break }
								"FailedJob" {$FailedJob = $Value; break }
								"InProgressJob" {$InProgressJob = $Value; break }
								"SuspendedJob" {$SuspendedJob = $Value; break }
								"UsedDiskSize" {$UsedDiskSize = $Value; break }
								"GRSStorageUsage" {$GRSStorageUsage = $Value; break }
								"LRSStorageUsage" {$LRSStorageUsage = $Value; break }
								"ZRSStorageUsage" {$ZRSStorageUsage = $Value; break }
								"RAGZRSStorageUsage" {$RAGZRSStorageUsage = $Value; break }
							}
						
						}

            $VaultData += [pscustomobject]@{ 
		
        					Subscription = $SubscriptionName
							ResourceGroup = $VaultResourceGroup
							VaultName = $VaultName
							ProtectedItemCount = $ProtectedItemCount
							#InProgressJobsCount = $InProgressJobsCount
							#FailedJobsCount = $FailedJobsCount
							#FailedJob = $FailedJob
							#InProgressJob = $InProgressJob
							#SuspendedJob = $SuspendedJob
							#UsedDiskSize = $UsedDiskSize/1TB
							GRSStorageUsage = $GRSStorageUsage/1TB
							LRSStorageUsage = $LRSStorageUsage/1TB
							ZRSStorageUsage = $ZRSStorageUsage/1TB
							RAGZRSStorageUsage = $RAGZRSStorageUsage/1TB
							TotalStorageUsage = ($GRSStorageUsage + $LRSStorageUsage + $ZRSStorageUsage + $RAGZRSStorageUsage)/1TB
                            Date = (get-date -Format "dd-MMM-yyyy")
						}

        }
        else{
            
            AddtoLogfile "Unable to receive response for vault $($vaultName)"

        }
    }

    $VaultData | Export-Csv -Path $pathToNewCsv -NoTypeInformation -Append -force

}catch{
    
    $errorUsage = "Error while requesting vault usage api - $($error[0])"
    AddtoLogfile $errorUsage
    Exit
}    

}

Function sendMail{
param()

try{    
    
    #removing old file 
    Remove-Item -Path $pathToCsvFile
    if((Test-Path -Path $pathToCsvFile) -eq $true){
        
        AddtoLogfile "Unable to delete previous file"
        Exit
    }
    else{
        
        AddtoLogfile "Previous file has been deleted"
        AddtoLogfile "Renaming the new file"
        Rename-Item -Path $pathToNewCsv -NewName $pathToCsvFile -Force
        if((Test-Path -Path $pathToCsvFile) -eq $true){
        
            AddtoLogfile "File has been renamed successfully. Sending it over email."
            $SMTPServer = $inputsPath.email.smtpServer 
            $To = $inputsPath.email.to 
            $from = $inputsPath.email.from 
            $attachment = $pathToCsvFile
            $cc = $inputsPath.email.cc
            $body = "Please find attached last four weeks vault usage report."

            Send-MailMessage -smtpserver $SMTPServer -From $From -To $To -Cc $cc -Subject "MMG Last Four Weeks Vault Usage Report" -Body $body -Attachments $attachment -BodyAsHtml
            if($? -eq $true){
            
                AddtoLogfile "Email sent successfully."

            }
            

        }
        else{
            
            AddtoLogfile "Failed to rename the file."
            Exit

        }
    }
}catch{
    
    $mailError = "Error while sending email - $($error[0])"
    AddtoLogfile $mailError
}    

}
#endregion


#region Variables
#####
#get current script path
$myScriptPath = $MyInvocation.MyCommand.Path
$jsonPath = "$(split-path $myScriptPath -Parent)\config.json"
$inputsPath = get-content "$(split-path $myScriptPath -Parent)\inputs.json" | ConvertFrom-Json

#Log Files
$todaysDate = Get-Date -Format "dd_MM_yyyy_hh_mm_ss"
$pathtoLogFile = $($inputsPath.pathToLog) + "\four_weeks_vault_usage_$($todaysDate).log"
$pathToCsvFile = $($inputsPath.pathToCsv) + "\four weeks vault usage\Four_Weeks_Vault_Usage.csv"
#path to new csv
$pathToNewCSV = ($($inputsPath.PathToCsv) + "\four weeks vault usage\Four_Weeks_Vault_Usage_latest.csv")


#Validate csv file creation
if((test-path -path $pathToCsvFile) -eq $false){
    
    New-Item -Path $pathToCsvFile -Force
    if((test-path -path $pathToCsvFile) -eq $false){
        
        AddtoLogfile "Unable to Create Excel File - $($error[0])"
        Exit
    }
}

#endregion


#region Main
#####
try{

AddtoLogfile "$(get-date) - Script Initiated"    
LoginToAzure

AddtoLogfile "Removing old data from file $($pathToCsvFile)"
RemoveOldData

AddtoLogfile "Adding new data to the new file"
AddtoLogfile "Fetchign all subscriptions"
$subscriptions = Get-AzSubscription
foreach($subscription in $subscriptions){
    
    AddtoLogfile "Setting Context to subscription $($subscription.Name)"
    Set-AzContext -Subscription $Subscription.Id
    $subscriptionName = $subscription.Name
    $token = (Get-AzAccessToken -TenantId $subscription.tenantId ).Token
    $apiVersion = "2016-06-01"
    $authHeader = @{"Authorization" = "Bearer $Token";'Accept'='application/json'}

    VaultUsage

}

AddtoLogfile "Preparing to send email"
sendmail

AddtoLogfile "$(get-date) - Script Ended"    
}catch{
    
    $errorMain = "Error in the region Main - $($error[0])."
    AddtologFile $errorMain

}
#endregion