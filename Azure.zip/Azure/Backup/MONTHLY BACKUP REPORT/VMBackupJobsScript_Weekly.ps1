﻿
<#--
Title: Powershell Script to fetch the Azure VM Backup Jobs current detail report
Description: This script recursively fetches the current backup job detail of Azure VMs across all the subscriptions and Recovery Service Vaults
Report Fields: Subscription, ResourceGroup, VMName, VaultName, Status, StartTime, EndTime, Duration
Report Summary: Total Subscriptions, Total No. of RSV, Total No. of Jobs, Completed, In Progress, Failed
Report Format: Comma Separated Values (CSV), Time Format UTC
Created By: Preeti Mittal 
Released On: 22-April-2020
--#>

Login-AzureRmAccount

$azure_recovery_services_vault_list = @()
$backup_job_list = @()
$backupjob_details = $null 
$backupjob_details = @()
$SubCount = 0
$RSVCount = 0
$TotalCount = 0
$CompleteCount = 0
$InProgressCount = 0
$FailedCount = 0
$timeStamp = $null
#Enable these parameters and provide value if report needs to be generated for a specific date range (Max 30 days)
#[datetime]$start = '2020-12-14 05:30:00'
#[datetime]$end = '2020-12-21 05:30:00'
$s = get-date -hour 0 -minute 0 -second 0
$s = $s.AddDays(-($s).DayOfWeek.value__).AddDays(1).AddHours(5).AddMinutes(30) 
[datetime]$start = $s.AddDays(-7)
[datetime]$end = $s

Write-Host ("Start Date = " + $start.ToString())
Write-Host ("End Date = " + $end.ToString())


$Subscriptions = Get-AzureRmSubscription

foreach ($sub in $Subscriptions)
{
    $SubCount += 1

    Select-AzureRmSubscription -Scope CurrentUser -Subscription $Sub.Name 

    $azure_recovery_services_vault_list = $null

    $azure_recovery_services_vault_list = Get-AzureRmRecoveryServicesVault   

    foreach ($vault in $azure_recovery_services_vault_list)
    {
        $RSVCount += 1
        
        Write-Host $vault.Name
        
        Set-AzureRmRecoveryServicesVaultContext -Vault $vault    
        
        #only UTC format is supported
        $backup_job_list = Get-AzureRmRecoveryServicesBackupJob -From $start.ToUniversalTime() -To $end.ToUniversalTime()  
        #$backup_job_list = Get-AzureRmRecoveryServicesBackupJob     

        #Write-Host $backup_job_list.Count.ToString()

        foreach ($backup_job in $backup_job_list)
        {

        if ($backup_job.BackupManagementType -eq "AzureVM")

            {
                $TotalCount+= 1

                switch ($backup_job.Status)
                {

                    "InProgress" { $InProgressCount += 1 }
                    "Failed" { $FailedCount += 1 }
                    default { $CompleteCount += 1 }
                }

                $backup_details_temp = New-Object psobject 

                $backup_details_temp | Add-Member -MemberType NoteProperty -Name "Subscription" -Value $sub.Name
                #$backup_details_temp | Add-Member -MemberType NoteProperty -Name "ResourceGroup" -Value $vault.ResourceGroupName 
                #$backup_details_temp | Add-Member -MemberType NoteProperty -Name "BackupJobID" -Value $backup_job.JobId 
                #$backup_details_temp | Add-Member -MemberType NoteProperty -Name "BackupManagementType" -Value $backup_job.BackupManagementType
                $backup_details_temp | Add-Member -MemberType NoteProperty -Name "VMName" -Value $backup_job.WorkloadName
                $backup_details_temp | Add-Member -MemberType NoteProperty -Name "VaultName" -Value $vault.Name 
                $backup_details_temp | Add-Member -MemberType NoteProperty -Name "Status" -Value $backup_job.Status 
                $backup_details_temp | Add-Member -MemberType NoteProperty -Name "StartTime" -Value $backup_job.StartTime
                $backup_details_temp | Add-Member -MemberType NoteProperty -Name "EndTime" -Value $backup_job.EndTime
                #$backup_details_temp | Add-Member -MemberType NoteProperty -Name "Duration" -Value $backup_job.Duration
                #$backup_details_temp | Add-Member -MemberType NoteProperty -Name "ErrorDetails" -Value $backup_job.ErrorDetails
                $backup_details_temp | Add-Member -MemberType NoteProperty -Name "Operation" -Value $backup_job.Operation
        
                $backupjob_details = $backupjob_details + $backup_details_temp 

            }         
        }      
    }
}

Write-Output "`n`n************** Summary **************`n"
Write-Output "Total Subscriptions = $SubCount"
Write-Output "Total No. of RSV = $RSVCount"
Write-Output "Total No. of Jobs = $TotalCount"
Write-Output "Completed = $CompleteCount"
Write-Output "In Progress = $InProgressCount"
Write-Output "Failed = $FailedCount"
Write-Output "`n*********** End of Script ***************"


$timeStamp = $(((get-date).ToUniversalTime()).ToString("yyyyMMddTHHmmssZ"))
$backupjob_details | Export-Csv "C:\temp\vm_backupjobs_ $timeStamp .csv" -NoTypeInformation -NoClobber