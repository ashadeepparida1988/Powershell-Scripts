﻿##### Date Range
$from = Get-Date -Year 2020 -Month 08 -Day 1 -Hour 0 -Minute 0 -Second 0
$to = (get-date $from ).AddMonths(12).AddSeconds(-1)

#######
$from
$to
$vmData = @()

####Get All VMs
$vms = Get-AzVM | Select *

foreach($vm in $vms){
    

    $osDisk = Get-AzDisk -ResourceGroupName $vm.ResourceGroupName -DiskName $vm.StorageProfile.OSDisk.Name
    $vm.Name
    If(($osDisk.TimeCreated -gt $from) -and ($osDisk.TimeCreated -lt $to)){
        
        $vmData += [pscustomobject]@{
                    
                        "Server Name" = $vm.Name
                        "Resource Group" = $vm.ResourceGroupName
                        "Date Created" = (Get-Date $osDisk.TimeCreated -Format "dd/MM/yyyy")
                        "OS Type" = $vm.StorageProfile.ImageReference.Offer
                   }
    }
}

#### Export Data
$vmData |  Export-Csv -Path "C:\Temp\yearly_Vms_Created.csv" -Delimiter "," -NoTypeInformation

