﻿## My Creds
$creds = Get-Credential

#get list of servers
$getVms = Get-AzVM | select *

## Variables
$getUptime = @()
foreach($vm in $getVms){
    
    "***** $($vm.Name) *****"
    if($vm.OSProfile.WindowsConfiguration -ne $null){
        
        $serverUptime = Get-WmiObject -Class win32_operatingsystem -ComputerName $vm.Name -Credential $creds  |select csname, @{LABEL=’LastBootUpTime’;EXPRESSION={$_.ConverttoDateTime($_.lastbootuptime)}}
        
        if($serverUptime){
            
            $getUptime += [pscustomobject]@{
    
                "Server Name" = $serverUptime.csname
                "Last Reboot Time" = $serverUptime.lastbootuptime
            }
        
        }
        else{
            
            "Unable to fetch uptime for WindowsServer: $($vm.Name)"
        }
    }
    else{
        
        "$($vm.Name):$($vm.StorageProfile.ImageReference.Offer)"
    }

}
$getUptime
$getUptime |  Export-Csv -Path "C:\Temp\servers_uptime.csv" -Delimiter "," -NoTypeInformation